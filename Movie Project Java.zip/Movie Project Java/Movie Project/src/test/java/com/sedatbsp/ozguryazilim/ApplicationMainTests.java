package com.sedatbsp.ozguryazilim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationMainTests {

    @Test
    void contextLoads() {
    }

}
