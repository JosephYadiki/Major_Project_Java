package com.sedatbsp.ozguryazilim.repository;

import com.sedatbsp.ozguryazilim.model.Actor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IActorRepository extends JpaRepository<Actor,Long> {

}
